
import React from 'react';
import { CustomerInfo } from '../types';
import UserIcon from './icons/UserIcon';
import PhoneIcon from './icons/PhoneIcon';

interface CustomerInfoPanelProps {
  customerInfo: CustomerInfo;
}

const CustomerInfoPanel: React.FC<CustomerInfoPanelProps> = ({ customerInfo }) => {
  const hasInfo = customerInfo.name || customerInfo.phone;

  return (
    <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg">
      <h2 className="text-lg font-semibold mb-3">Thông Tin Khách Hàng</h2>
      {hasInfo ? (
        <div className="space-y-3">
          {customerInfo.name && (
            <div className="flex items-center gap-3">
              <UserIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />
              <span className="text-sm font-medium">{customerInfo.name}</span>
            </div>
          )}
          {customerInfo.phone && (
            <div className="flex items-center gap-3">
              <PhoneIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />
              <span className="text-sm font-medium">{customerInfo.phone}</span>
            </div>
          )}
        </div>
      ) : (
        <p className="text-sm text-gray-500 dark:text-gray-400">Chưa có thông tin được ghi nhận.</p>
      )}
    </div>
  );
};

export default CustomerInfoPanel;
